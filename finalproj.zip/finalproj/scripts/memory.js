

const Memory = {

    currentVisitor: null,

    lastVisitor: null

};