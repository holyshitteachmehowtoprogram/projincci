const Target = {

    candidate:false,

    locked:false,

    justLocked:false,

    justReleased:false,

    lockStart:0,

    lostStart:0,

    lockDelay:3000,

    releaseDelay:5000

};



function updateTarget(){

    Target.justLocked = false;
    Target.justReleased = false;


    if(Target.locked){


        if(!Sensor.present){


            if(Target.lostStart==0){

                Target.lostStart=
                millis();

            }


            if(

                millis()-Target.lostStart>

                Target.releaseDelay

            ){

                Target.locked=false;

                Target.candidate=false;

                Target.lostStart=0;

                console.log(
                    "TARGET RELEASED"
                );

            }


        }

        else{

            Target.lostStart=0;

        }


        return;

    }



    // 没锁定


    if(Sensor.present){


        if(!Target.candidate){

            Target.candidate=true;

            Target.lockStart=
            millis();

        }


        else{


            if(

                millis()-Target.lockStart>

                Target.lockDelay

            ){

                Target.locked = true;
                Target.justLocked = true;
                Target.candidate = false;   // ← 很重要

                console.log("TARGET LOCKED");

            }


        }


    }


    else{


        Target.candidate=false;

    }

}