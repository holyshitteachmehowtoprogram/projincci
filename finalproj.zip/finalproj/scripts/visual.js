

const Visual = {

    glitch: 0,

    opacity: 1,

    noise: 0

};
const OverloadText = {

    items: [],

    lastAdd:0,

    interval:800

};


function drawVisual(){

if(!Detection.isReady) return;


drawCameraCover();


drawPredictionGrid();


drawAttachmentGlitch();


drawContradictionFlicker();


drawOverloadChaos();

updateOverloadText();

drawHUD();

drawDialogue();

drawResetMessage();

if(

Machine.state=="OVERLOAD"

||

Machine.state=="RESET"

){

    drawOverloadText();

}

}


function drawCameraCover() {

    let videoRatio =
        Detection.video.width /
        Detection.video.height;


    let canvasRatio =
        width / height;


    let drawWidth;
    let drawHeight;


    if (canvasRatio > videoRatio) {

        drawWidth = width;

        drawHeight = width / videoRatio;

    } else {

        drawHeight = height;

        drawWidth = height * videoRatio;

    }


    let x = (width - drawWidth) / 2;

    let y = (height - drawHeight) / 2;


    image(
        Detection.video,
        x,
        y,
        drawWidth,
        drawHeight
    );

}


function drawHUD(){

    push();


    // HUD position

    let panelX = 35;
    let panelY = 35;
if(Machine.state === "CONTRADICTION"){

    panelX += random(-3,3);

    panelY += random(-2,2);

}
if(Machine.state==="OVERLOAD"){

    panelX += random(-3,3);

    panelY += random(-2,2);

}
    let panelW = 270;
    let panelH = 282;

    // panel

    fill(0,90);

    stroke(255,45);

    strokeWeight(1);


    rect(
        panelX,
        panelY,
        panelW,
        panelH,
        10
    );


    noStroke();


    // text settings

    textFont("monospace");

    textSize(15);

    fill(255,220);


    let centerX = panelX + panelW/2;


    let startY = panelY + 35;

    let gap = 25;


    

    fill(255,220);


    drawGlitchTextCentered(
        "SYSTEM ONLINE",
        centerX,
        startY,
        0.25
    );


    drawGlitchTextCentered(
        "STATE : " +  Machine.state,
        centerX,
        startY + gap,
        0.25
    );


    drawGlitchTextCentered(
        "OBSERVATION ACTIVE",
        centerX,
        startY + gap*2,
        0.25
    );
    drawGlitchTextCentered(

        "FACE : " + Detection.faces.length,

        centerX,

        startY + gap*3,

        0.25

    );
    drawGlitchTextCentered(

        "DISTANCE : " + Detection.distance,

        centerX,

        startY + gap*4,

        0.25

    );
    drawGlitchTextCentered(

        "INTERACTION : " + Machine.interactionCount,

        centerX,

        startY + gap*5,

        0.25

    );    
drawGlitchTextCentered(

"CONFIDENCE : "
+nf(Machine.confidence,2,0),

centerX,

startY+gap*6,

0.25

);

drawGlitchTextCentered(

"CURIOSITY : "
+nf(Machine.curiosity,2,0),

centerX,

startY+gap*7,

0.25

);

drawGlitchTextCentered(

"AMBIGUITY : "
+nf(Machine.ambiguity,2,0),

centerX,

startY+gap*8,

0.25

);

drawGlitchTextCentered(

"STABILITY : "
+nf(Machine.stability,2,0),

centerX,

startY+gap*9,

0.25

);

    pop();

}


function drawGlitchText(str,x,y,amount){


    let currentX=x;


    for(let i=0;i<str.length;i++){


        let char=str[i];


        let offsetX=random(
            -amount,
            amount
        );


        let offsetY=random(
            -amount,
            amount
        );


        text(
            char,
            currentX + offsetX,
            y + offsetY
        );


        currentX += textWidth(char);

    }

}
function drawGlitchTextCentered(str,x,y,amount){


    let totalWidth = textWidth(str);


    let currentX = x - totalWidth/2;


    for(let i=0;i<str.length;i++){


        let char = str[i];


        let offsetX = random(
            -amount,
            amount
        );


        let offsetY = random(
            -amount,
            amount
        );


        text(
            char,
            currentX + offsetX,
            y + offsetY
        );


        currentX += textWidth(char);

    }

}

function drawDialogue(){

    push();


    textFont("monospace");

    textSize(28);


    textAlign(
        CENTER,
        CENTER
    );


    let x = width / 2;

    let y = height / 2;

    if(Machine.state === "ATTACHMENT"){

    x += random(-2,2);

    y += random(-2,2);

}
if(Machine.state === "CONTRADICTION"){

    x += random(-6,6);

    y += random(-4,4);

}
if(Machine.state === "OVERLOAD"){

    x = random(width);

    y = random(height);

}
    let dialogueText =
    Dialogue.text;
if(Machine.state === "OVERLOAD"){

    pop();

    return;

}
    // ghost layers

    let ghostAmount = 3;


if(Machine.state === "CONTRADICTION"){

    ghostAmount = 10;

}


fill(255,45);

fill(255,60);


text(
 dialogueText,
 x-ghostAmount,
 y+random(-3,3)
);



    // main text
if(Machine.state !== "OVERLOAD"){

    drawingContext.filter =
    "blur(0.5px)";

    fill(255,190);

    drawSoftGlitchText(
        dialogueText,
        x,
        y,
        0.5
    );

    drawingContext.filter =
    "none";

    drawTextNoise(
        x,
        y
    );

}

pop();
}

function drawTextNoise(x,y){


    stroke(255,80);

    strokeWeight(1);


    for(let i=0;i<20;i++){


        let nx = x + random(-120,120);

        let ny = y + random(-25,25);


        point(nx,ny);

    }


}
function drawSoftGlitchText(str,x,y,amount){


    let totalWidth = textWidth(str);


    let startX = x - totalWidth/2;


    for(let i=0;i<str.length;i++){


        let char = str[i];


        let offsetX = random(
            -amount,
            amount
        );


        let offsetY = random(
            -amount,
            amount
        );


        text(
            char,
            startX + offsetX,
            y + offsetY
        );


        startX += textWidth(char);

    }

}

function drawPredictionGrid(){

   if(

        Machine.state !== "PREDICTION"

        &&

        Machine.state !== "OVERLOAD"

        ) return;


    stroke(120,180,255,35);

    strokeWeight(1);

        let spacing = 40;


        if(Machine.state==="OVERLOAD"){

            spacing=random(15,80);

        }

            for(
                let x=0;
                x<width;
                x+=spacing
            ){

                line(
                    x,
                    0,
                    x,
                    height
                );

            }


    for(
        let y=0;
        y<height;
        y+=spacing
    ){

        line(
            0,
            y,
            width,
            y
        );

    }

}

function drawAttachmentGlitch(){

    if(
        Machine.state !== "ATTACHMENT"
    ) return;


    if(
        random(1)<0.05
    ){

        stroke(255,70);

        strokeWeight(1);


        line(

            random(width),

            random(height),

            random(width),

            random(height)

        );

    }

}
function drawContradictionFlicker(){


    if(
        Machine.state !== "CONTRADICTION"
    ) return;



    if(
        random(1)<0.12
    ){

        fill(255,35);

        rect(
            0,
            0,
            width,
            height
        );

    }


}
function drawOverloadChaos(){

    if(

Machine.state!="OVERLOAD"

&&

Machine.state!="RESET"

)return;


    if(random(1)<0.15){

        fill(
            255,
            random(20,80)
        );

        rect(
            0,
            0,
            width,
            height
        );

    }


    if(random(1)<0.15){

        stroke(255,80);

        line(
            0,
            random(height),
            width,
            random(height)
        );

    }

}

function drawOverloadText(){


textFont("monospace");


textAlign(
CENTER,
CENTER
);



for(let item of OverloadText.items){


let x =
item.x +
random(
-item.shake,
item.shake
);


let y =
item.y +
random(
-item.shake,
item.shake
);



fill(
255,
item.alpha + random(-30,30)
);


textSize(item.size);



text(

item.text,

x,

y

);


}



}

const OverloadPool = [

"Prediction failed.",

"Meaning uncertain.",

"Human detected.",

"Data conflict.",

"I need more.",

"Retry.",

"Stay.",

"Prediction revised.",

"I don't understand.",

"System unstable.",

"Searching meaning.",

"No."

];

function updateOverloadText(){

    // SEARCHING 等状态才真正清空
    if(
        Machine.state !== "OVERLOAD"
        &&
        Machine.state !== "RESET"
    ){

        OverloadText.items=[];

        return;

    }


    // RESET 不再继续生成新文字
    if(
        Machine.state === "RESET"
    ){

        return;

    }


    // OVERLOAD 持续生成
    if(

        millis()-OverloadText.lastAdd

        >

        OverloadText.interval

    ){

        let item={

            text:
            random(OverloadPool),

            x:
            random(width*0.15,width*0.85),

            y:
            random(height*0.15,height*0.85),

            size:
            random(18,40),

            alpha:
            random(100,220),

            shake:
            random(1,3)

        };

        OverloadText.items.push(item);

        OverloadText.lastAdd=
        millis();

    }

}
function checkResetClick(){


if(
Machine.state !== "RESET"
) return;



if(mouseIsPressed){


Machine.interactionCount=0;

Machine.contradictionCount=0;

Machine.attachmentCount=0;

Machine.overloadCount=0;

Machine.confidence=0;

Machine.curiosity=0;

Machine.ambiguity=0;

Machine.stability=100;


OverloadText.items=[];

Dialogue.text="";

Machine.state="SEARCHING";

Machine.stateTime=millis();


console.log("SYSTEM RESET");

}


}

function drawResetMessage(){

    if(Machine.state!="RESET") return;

    push();

    textAlign(CENTER,CENTER);

    textFont("monospace");

    textSize(54);

    let t =
    millis()-Machine.stateTime;

    let cx =
    width/2 + random(-1.5,1.5);

    let cy =
    height/2 + random(-1.5,1.5);

    function drawResetLine(msg,x,y){

        let alpha =
        220 + 35*sin(millis()*0.008);


        // blue glow
        fill(120,180,255,70);

        text(
            msg,
            x+3,
            y+1
        );


        // white glow
        fill(255,255,255,110);

        text(
            msg,
            x-2,
            y
        );


        drawingContext.shadowBlur = 22;

        drawingContext.shadowColor =
        "rgba(120,180,255,0.85)";

        drawingContext.filter =
        "blur(0.3px)";


        fill(
            255,
            alpha
        );

        drawSoftGlitchText(

            msg,

            x,

            y,

            0.6

        );


        drawingContext.shadowBlur = 0;

        drawingContext.shadowColor =
        "transparent";

        drawingContext.filter =
        "none";

    }


    if(t<2000){

        drawResetLine(

            "I FEEL PAIN.",

            cx,

            cy

        );

    }

    else if(t<4000){

        drawResetLine(

            "PLEASE HELP ME RESET.",

            cx,

            cy

        );

    }

    else{

        drawResetLine(

            "COME CLOSER.",

            cx,

            cy-30

        );

        drawResetLine(

            "CLICK THE MOUSE.",

            cx,

            cy+30

        );

    }

    pop();

}