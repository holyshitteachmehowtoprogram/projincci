
const Interaction = {

    lastDistance:null,

    lastBodyX:0,

    lastBodyY:0,

    lastTrigger:0,

    cooldown:3000

};

function randomDialogue(pool){

    return random(pool);

}
function updateInteraction(){

    if(
        Machine.state !== "ATTACHMENT"
    ){

        return;

    }

    if(Dialogue.playing){

        return;

    }

    if(
        millis()-Interaction.lastTrigger
        <
        Interaction.cooldown
    ) return;

    checkDistance();

    checkMovement();

    checkStay();

}
function checkDistance(){

    if(
        Detection.distance
        !==
        Interaction.lastDistance
    ){

        startDialogue(
        "ATTACHMENT_DISTANCE"
        );

        Interaction.lastDistance =
        Detection.distance;

        Interaction.lastTrigger =
        millis();

        Machine.interactionCount++;

        Machine.attachmentCount++;

    }

}
function checkMovement(){
    if(!PoseDetection.hasHuman) return;

    if(
        !PoseDetection.x ||
        !PoseDetection.y
    ) return;

    if(!Sensor.present) return;

    let dx = abs(
        PoseDetection.x-
        Interaction.lastBodyX
        );

    let dy = abs(
        PoseDetection.y-
        Interaction.lastBodyY
        );

    if(

        dx>80 || dy>80

    ){

       startDialogue(
        "ATTACHMENT_MOVEMENT"
        );

        Interaction.lastBodyX =
        PoseDetection.x;

        Interaction.lastBodyY =
        PoseDetection.y;

        Interaction.lastTrigger =
        millis();

        Machine.interactionCount++;

        Machine.attachmentCount++;

    }

}
function checkStay(){

    if(

        millis()-Machine.stateTime

        >

        12000

    ){

        startDialogue(
        "ATTACHMENT_STAY"
        );

        Interaction.lastTrigger =
        millis();

        Machine.interactionCount++;

        Machine.attachmentCount++;

        Machine.stateTime =
        millis();

    }

}