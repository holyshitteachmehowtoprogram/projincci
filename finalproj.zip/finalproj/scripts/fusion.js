const Sensor = {


    present:false,

    distance:"none",

    confidence:"low"


};



function updateSensor(){


    // 人体存在判断

    Sensor.present =
        PoseDetection.hasHuman;



    // 距离来自 FaceMesh

    if(Detection.hasHuman){


        Sensor.distance =
            Detection.distance;


        Sensor.confidence =
            "high";


    }

    else{


        if(Sensor.present){


            Sensor.confidence =
                "medium";


        }

        else{


            Sensor.distance =
                "none";


            Sensor.confidence =
                "low";


        }


    }
   

}