

const Detection = {

    video:null,

    detector:null,

    faces:[],

    isReady:false,

    hasHuman:false,

    distance:"none",

    lastSeen:0,

    lostTime:3000

};

async function initDetection(){


    Detection.video = createCapture(VIDEO);


    Detection.video.size(
        640,
        480
    );


    Detection.video.hide();



    Detection.detector = ml5.faceMesh({

        maxFaces: 1,

        refineLandmarks: true

    });



    Detection.detector.ready.then(()=>{


        Detection.detector.detectStart(

            Detection.video,

            gotFaces

        );


    });



    Detection.isReady = true;


}
function updateDetection() {

}
function gotFaces(results){


    Detection.faces = results;


    if(results.length > 0){


    Detection.hasHuman = true;


    Detection.lastSeen =
        millis();


}
else{


    if(
        millis() - Detection.lastSeen
        > Detection.lostTime
    ){

        Detection.hasHuman = false;

    }


}



    if(results.length > 0){


        let face = results[0];


        let keypoints = face.keypoints;


        let minX = width;

        let maxX = 0;


        let minY = height;

        let maxY = 0;



        for(let i = 0; i < keypoints.length; i++){


            let x = keypoints[i].x;

            let y = keypoints[i].y;



            if(x < minX) minX = x;

            if(x > maxX) maxX = x;


            if(y < minY) minY = y;

            if(y > maxY) maxY = y;


        }



        let faceWidth =
            maxX - minX;



        let ratio =
            faceWidth / Detection.video.width;



        



        if(ratio < 0.12){

            Detection.distance = "far";

        }

        else if(ratio < 0.28){

            Detection.distance = "medium";

        }

        else{

            Detection.distance = "close";

        }


    }

    else{


        Detection.distance = "none";


    }


}