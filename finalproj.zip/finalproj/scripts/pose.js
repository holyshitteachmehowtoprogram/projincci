const PoseDetection = {

    detector:null,

    poses:[],

    hasHuman:false,

    x:0,

    y:0

};
function initPose(){


    PoseDetection.detector =
        ml5.bodyPose();


    PoseDetection.detector.ready.then(()=>{


        console.log(
            "Pose Ready"
        );


        PoseDetection.detector.detectStart(

            Detection.video,

            gotPose

        );


    });


}



function gotPose(results){

    PoseDetection.poses = results;

    PoseDetection.hasHuman = results.length > 0;

    if(results.length>0){

        let nose =
        results[0].nose;

        if(nose){

            PoseDetection.x = nose.x;

            PoseDetection.y = nose.y;

        }

    }

}