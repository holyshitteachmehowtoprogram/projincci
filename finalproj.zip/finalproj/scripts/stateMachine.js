
const STATES = {
    SEARCHING: "SEARCHING",
    RECOGNITION: "RECOGNITION",
    PREDICTION: "PREDICTION",
    ATTACHMENT: "ATTACHMENT",
    CONTRADICTION: "CONTRADICTION",
    OVERLOAD: "OVERLOAD",
    RESET: "RESET"
};

const AI = {
    currentState: STATES.SEARCHING,

    confidence: 1,
    curiosity: 0,
    ambiguity: 0,
    stability: 1
};

function changeState(newState) {
    AI.currentState = newState;
    console.log("Current State:", AI.currentState);
}