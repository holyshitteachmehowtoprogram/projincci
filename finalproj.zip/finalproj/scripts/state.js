const Machine = {

    state:"SEARCHING",

    previousState:"SEARCHING",

    stateTime:0,

    recognitionFinished:false,

    observationTime:0,

    interactionCount:0,

    contradictionCount:0,

    attachmentCount:0,

    overloadCount:0,

    resetRequested:false,

    confidence:0,

    curiosity:0,

    ambiguity:0,

    contradictionPlayed:false,

    stability:100

};


function updateState(){

    let newState = Machine.state;


    // 没有人

    if(!Target.locked && !Target.candidate){

        newState = "SEARCHING";

        Machine.recognitionFinished = false;

    }
    else if(Target.candidate && !Target.locked){

    newState = "SEARCHING";

}

    // 有人进入

    else{

        switch(Machine.state){

            case "SEARCHING":

                newState = "RECOGNITION";

                break;


           case "RECOGNITION":

            Machine.confidence =
            min(
                Machine.confidence + 0.2,
                20
            );

            if(

                Detection.distance !== "far"
                &&
                millis()-Machine.observationTime>3000

            ){

                newState="PREDICTION";

            }

        break;

       case "PREDICTION":

            Machine.confidence =
            min(
                Machine.confidence + 0.3,
                80
            );

            let stayTime =
            millis()-Machine.observationTime;

            if(stayTime>8000){

                newState="ATTACHMENT";

            }

        break;

        case "ATTACHMENT":

            if(
                Machine.attachmentCount >=4
            ){

                newState="CONTRADICTION";

                Dialogue.playing=false;
                Dialogue.queue=[];
                Dialogue.text="";

            }

        break;
                    
        case "CONTRADICTION":


        if(

            !Dialogue.playing

            &&

            Machine.overloadCount < 5

            &&

            !Machine.contradictionPlayed

        ){

            Machine.overloadCount++;

            Machine.contradictionPlayed = true;

            startDialogue("CONTRADICTION_GENERAL");

        }
        // 剧本结束后允许下一轮

        if(

            !Dialogue.playing

            &&

            Machine.contradictionPlayed

        ){

            Machine.contradictionPlayed = false;

        }



        if(

            Machine.overloadCount >=5

            &&

            !Dialogue.playing

        ){

            newState="OVERLOAD";

}


break;

    case "OVERLOAD":

            if(

                millis()-Machine.stateTime

                >

                15000

            ){

                newState="RESET";

            }
                    console.log(
        millis()-Machine.stateTime
        );
        break;

         case "RESET":

            Machine.interactionCount=0;

            Machine.contradictionCount=0;

            Machine.overloadCount=0;

            Machine.confidence=0;

            Machine.curiosity=0;

            Machine.ambiguity=0;

            Machine.stability=100;
            Machine.overloadCount=0;

            Machine.contradictionPlayed=false;

            Machine.recognitionFinished=false;

            

        break;
        }

    }


    if(newState !== Machine.state){

        Machine.previousState = Machine.state;

        Machine.state = newState;

        updateSystemMetrics();

        Machine.stateTime = millis();

        console.log("STATE:", Machine.state);
        if(
    Machine.state === "RECOGNITION"
        ){

            Machine.observationTime =
            millis();

        }

    }

}
function updateSystemMetrics(){

switch(Machine.state){

case "SEARCHING":

Machine.curiosity=10;
Machine.ambiguity=0;
Machine.stability=100;

break;


case "RECOGNITION":

Machine.curiosity=30;
Machine.ambiguity=10;
Machine.stability=90;

break;


case "PREDICTION":

Machine.curiosity=50;
Machine.ambiguity=30;
Machine.stability=80;

break;


case "ATTACHMENT":

Machine.curiosity=70;
Machine.ambiguity=50;
Machine.stability=65;

break;


case "CONTRADICTION":

Machine.curiosity=90;
Machine.ambiguity=85;
Machine.stability=40;

break;


case "OVERLOAD":

Machine.curiosity=100;
Machine.ambiguity=100;
Machine.stability=5;

break;


}

}