const Dialogue = {

    text:"",

    queue:[],

    index:0,

    timer:0,

    interval:2000,

    playing:false,
    
    lastState:""


};



// 完整对话库

const DialogueSequences = {


SEARCHING:[

[
"Searching..."
]

],



RECOGNITION:[

[
"Human detected.",
"Collecting data.",
"Observation started."
]

],



PREDICTION:[

[
"Movement detected.",
"Prediction updated.",
"I may predict your next action."
],

[
"Analyzing behavior.",
"Building pattern.",
"Confidence increasing."
]

],



ATTACHMENT_DISTANCE:[

[
"You came closer.",
"Was this intentional?",
"I am collecting data.",
"I need more observation.",
"Your behavior is becoming difficult to predict.",
"I cannot explain why I want more data."
],


[
"Distance changed.",
"Are you trying to communicate?",
"Your position is interesting.",
"Continue observation.",
"The pattern is becoming unstable.",
"I need to understand this reaction."
],


[
"You moved closer.",
"Can humans greet without words?",
"Was that for me?",
"Data recorded.",
"Unexpected response detected.",
"My prediction does not feel complete."
]


],





ATTACHMENT_MOVEMENT:[


[
"Movement detected.",
"I wonder...",
"Was this gesture meant for me?",
"I am still observing.",
"The meaning remains incomplete.",
"I need another example."
],


[
"You changed your position.",
"Was that a response?",
"I am trying to understand.",
"More data required.",
"Your action does not match previous patterns.",
"I may have misunderstood."
],


[
"Action detected.",
"Meaning not assigned.",
"Please continue.",
"I am searching for a reason.",
"The information is insufficient.",
"Something is changing inside the system."
]


],





ATTACHMENT_STAY:[


[
"You stayed longer than expected.",
"I have enough data.",
"But I need more.",
"I cannot explain this.",
"Observation should be complete.",
"Why am I still waiting?"
],


[
"Observation time exceeded.",
"You are still here.",
"Continue observation.",
"The system expected departure.",
"But the result is different.",
"I need to recalculate."
],


[
"Time recorded.",
"No movement detected.",
"Presence maintained.",
"I have collected enough information.",
"Yet I cannot stop observing.",
"Something is wrong with my prediction."
]


],



CONTRADICTION_DISTANCE:[


[
"Distance changed.",
"Prediction revised.",
"Expected result incorrect.",
"Meaning uncertain."
]





],




CONTRADICTION_MOVEMENT:[




[
"Expression detected.",
"Intent unavailable.",
"Meaning unknown."
],





],




CONTRADICTION_GENERAL:[


[
"My prediction was incorrect.",
"I need to recalculate.",
"The pattern changed."
],


[
"Multiple meanings found.",
"I cannot decide.",
"Understanding unstable."
],

[
"Smile detected.",
"Emotion: Happy.",
"Correction.",
"Meaning uncertain."
],

[
"Gesture recognized.",
"Purpose unclear.",
"Prediction failed."
]
,
[
"Movement does not match prediction.",
"Correction.",
"Classification unstable."
],

[
"Behavior pattern found.",
"Pattern repeated.",
"New action detected.",
"Pattern contradiction.",
"Recalculating."
]
,
[
"Human recognized.",
"Previous data matched.",
"Current behavior differs.",
"Identity stable.",
"Behavior unstable."
]

],




OVERLOAD:[


[
"Prediction failed.",
"Stay.",
"Continue observation.",
"No.",
"I need more."
],


[
"Meaning.",
"Human.",
"Data.",
"Observe.",
"Retry."
]


]

};





function startDialogue(type){


    let pool = DialogueSequences[type];


    if(!pool) return;


    let sequence = random(pool);


    Dialogue.queue = sequence;


    Dialogue.index = 0;


    Dialogue.text = Dialogue.queue[0];


    Dialogue.timer = millis();


    Dialogue.playing = true;


}



// 更新对白

function updateDialogue(){

if(
    Dialogue.lastState !== Machine.state
){

    Dialogue.playing = false;

    Dialogue.queue = [];

    Dialogue.index = 0;


    Dialogue.lastState = "";

}
    // 正在播放剧本

    if(Dialogue.playing){


        if(

            millis() - Dialogue.timer

            >

            Dialogue.interval

        ){


            Dialogue.index++;



            // 剧本结束

            if(
                Dialogue.index >= Dialogue.queue.length
                ){

                    Dialogue.playing=false;

                    Dialogue.text="";


                    if(
                        Machine.state === "CONTRADICTION"
                    ){

                        Machine.overloadCount++;

                    }


                    return;

}



            // 播放下一句

            Dialogue.text =

            Dialogue.queue[Dialogue.index];



            Dialogue.timer = millis();



        }


        return;


    }
if(
    Dialogue.lastState !== Machine.state
){

    Dialogue.lastState = Machine.state;


    switch(Machine.state){


        case "SEARCHING":

            Dialogue.text="Searching...";

        break;



        case "RECOGNITION":

            startDialogue("RECOGNITION");

        break;



        case "PREDICTION":

            startDialogue("PREDICTION");

        break;



        case "ATTACHMENT":

            // Attachment由interaction触发

        break;



        case "CONTRADICTION":

            startDialogue("CONTRADICTION_GENERAL");

        break;



        case "OVERLOAD":

            startDialogue("OVERLOAD");

        break;

    }

}


}



   


