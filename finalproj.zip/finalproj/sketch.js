function setup(){

    createCanvas(
        windowWidth,
        windowHeight
    );

    initDetection();
    initPose();

}


function draw(){
    updateTarget();

    updateSensor();

    updateState();

    updateDialogue();

    updateInteraction();

    checkResetClick();

    background(0);

    updateDetection();

    drawVisual();

}


function windowResized(){

    resizeCanvas(
        windowWidth,
        windowHeight
    );

}